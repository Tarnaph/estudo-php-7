//: Playground - noun: a place where people can play

import UIKit

let tipoDeDados: String = "Dados Básicos"
let minhaString: String = "Dado de Texto"
let minhaInt: Int = 10
let minhaFloat: Float = 20.12
let minhaDouble: Double = 20.11235987654
var minhaBoll: Bool
minhaBoll = 2>1
minhaBoll = 2===3
let meuArray: Array = [1,2,3,4,5]
meuArray[0]+meuArray[2]

var operadoresMatematicos: String = "Operadores Matématicos"
var x: Int = 10
var y: Int = 2
print( x + y )
print(x - y)
print(x * y)
print(x / y)
print(x % y)
print(++x,x++)
print(--y,y--)

var a = 2
var b = 3
b += 2
b -= 3
b %= 2

var operadoresCondicionais : String = "Operadores Condicionais"
var c: Int = 3
var d: Int = 4
var e: Float = 2.312
var f: Double = 1.123123123123
c == d
c != d
c > d
c < d
c <= d
c >= d

var operadoresLogicos: String = "Operadores Lógicos"
var w = d & d
print("w=\(w)")
c | d

var comandosDeControle: String = "Comandos de Controle"
print("if(condição {code} else if {code} else {code})")
if a < b {
    print("a é mairo que b")
}
else {
    print("n sei ")
}

if x > 12 {
    print("caso 1 ok")
}
else if y == 0 {
    print("caso 2 ok")
}
else {
   print("caso 3 ok")
}

var sortIf: String = "Short If"
var shortIf: String = "\(sortIf): if - condição?true:false"
x>12 ? print("sim"):print("não")

var minhaSwitch: String = "Tipo if, mas com cases"

var index: Int = 10

for var index = 0; index <= 121; ++index {
    print("index is \(index)")
}
for index in 0...121 {print(index)}
print(index)
while (index == 10) {
    print("oio i o")
    break
}
repeat {
print("aqui vai repetir uma vez pelo menos")
}
while (index == 110)

var minhaFunc: String = ("func nomeDaFunc (paramentro) -> tipoderetorno { code } ")
print(minhaFunc)

var dadosAvancados: String;
dadosAvancados = "Dados Avançados"
print(dadosAvancados)
var dadoA: NSNumber = 20
dadoA.copy()

var atributos: NSArray = ["Força","Destreza","Int"]
print(atributos[1])

var skills: NSMutableArray = ["Força","Destreza","Int",""]
skills[1]
skills.removeObjectAtIndex(2)
print(skills)
skills.insertObject("Cont", atIndex: 3)
print(skills)

var nameOfBabys: NSDictionary = ["Raphael" : "Curado por deus", "Marcela" : "Deus"]
print(nameOfBabys)
nameOfBabys.objectForKey("Marcela")










